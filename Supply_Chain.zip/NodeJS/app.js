var http = require("http");
var express = require('express');
var app = express();
app.use(express.static('public'));
var mysql      = require('mysql');
var bodyParser = require('body-parser');

var session		=	require('express-session');
app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));
var sess;

var connection = mysql.createConnection({
  host     : 'localhost', //mysql database host name
  user     : 'root', //mysql database user name
  password : 'cdacacts', //mysql database password
  database : 'supplier_mgmt' //mysql database name
});

connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
});

app.get('/ulogin', function (req, res) {
   connection.query('select * from user_db where u_id=? and u_pwd=?',[req.query.val,req.query.val1], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  sess=req.session;	
	  sess.email=req.query.val;
	  res.end(JSON.stringify(results));
	});
});

app.get('/alogin', function (req, res) {
   connection.query('select * from admin_db where a_id=? and a_pwd=?',[req.query.val,req.query.val1], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  sess=req.session;	
	  sess.email=req.query.val;
	  res.end(JSON.stringify(results));
	});
});

app.get('/getuser', function (req, res) {
   sess=req.session;
   res.end(sess.email);
});

app.get('/logout',function(req,res){
	req.session.destroy(function(err) {
		if(err) console.log(err);
		res.end(sess.email);
	});
});

app.get('/suppliers', function (req, res) {
   connection.query('select * from supplier_db', function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/items', function (req, res) {
   connection.query('select * from item_db', function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/supplier_wise', function (req, res) {
   connection.query('select i_id,i_name from item_db where s_id=?',req.query.s_id, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/supplies', function (req, res) {
   connection.query('select * from supplies_db', function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/del_supplier', function (req, res) {
   connection.query('delete from supplier_db where s_id=?',req.query.s_id, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/del_item', function (req, res) {
   connection.query('delete from item_db where i_id=?',req.query.i_id, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/del_supply', function (req, res) {
   connection.query('delete from supplies_db where s_no=?',req.query.s_no, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/add_supplier', function (req, res) {
   connection.query('insert into supplier_db values(?,?,?)',[req.query.s_id,req.query.s_name,req.query.contract_expiry], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/supplier_exists', function (req, res) {
   connection.query('select * from supplier_db where s_id=?',req.query.s_id, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/add_item', function (req, res) {
   connection.query('insert into item_db values(?,?,?)',[req.query.i_id,req.query.i_name,req.query.s_id], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/item_exists', function (req, res) {
   connection.query('select * from item_db where i_id=?',req.query.i_id, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/add_supply', function (req, res) {
   connection.query('insert into supplies_db values(?,?,?)',[req.query.s_no,req.query.i_id,req.query.city], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/supply_exists', function (req, res) {
   connection.query('select * from supplies_db where s_no=?',req.query.s_no, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

app.get('/supplier_count', function (req, res) {
   connection.query('select count(distinct s_id) as s_count from item_db where i_id in(select i_id from supplies_db where city=?)',req.query.city, function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  res.end(JSON.stringify(results));
	});
});

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   
   console.log("Example app listening at http://%s:%s", host, port)
})