var http = require("http");
var express = require('express');
var app = express();
app.use(express.static('public'));
app.listen(8081);
var mysql      = require('mysql');
var bodyParser = require('body-parser');

var session		=	require('express-session');
app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));
var sess;

var connection = mysql.createConnection({
  host     : 'localhost', //mysql database host name
  user     : 'root', //mysql database user name
  password : 'cdacacts', //mysql database password
  database : 'supplier_mgmt' //mysql database name
});

connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...');
});

app.get('/ulogin', function (req, res) {
   connection.query('select * from user where u_id=? and password=?',[req.query.val,req.query.val1], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  sess=req.session;	
	  sess.email=req.query.val;
	  res.end(JSON.stringify(results));
	});
});

app.get('/alogin', function (req, res) {
   connection.query('select * from admin where a_id=? and a_pass=?',[req.query.val,req.query.val1], function (error, results, fields) {
	  if (error) throw error;
	  console.log(JSON.stringify(results));
	  sess=req.session;	
	  sess.email=req.query.val;
	  res.end(JSON.stringify(results));
	});
});

app.get('/getuser', function (req, res) {
   sess=req.session;
   res.end(sess.email);
});

app.get('/logout',function(req,res){
	req.session.destroy(function(err) {
		if(err) console.log(err);
		res.end(sess.email);
	});
});