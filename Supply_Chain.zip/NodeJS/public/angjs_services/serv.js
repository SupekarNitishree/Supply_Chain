var xapp = angular.module("xapp", []);
xapp.service('xservice', function(){
	var id=1;
	var items = [];
	this.save = function(contact){
		if(!contact.id){
			contact.id = id++;
			items.push(contact);
		}else{
			for(i in items){
				if(items[i].id == contact.id)
					items[i] = contact;
			}	
		}
	};

	this.get = function(id){
		for(i in items){
			if(items[i].id == id)
				return items[i];
		}
	};

	this.list = function(){
		return items;
	};

	this.delete = function(id){
		for(i in items){
			if(items[i].id == id)
				items.splice(i, 1);
		}
	};
});
xapp.controller("xcontroller", function($scope, xservice) {
	$scope.contacts = xservice.list();
	$scope.add = function(){
		if(!$scope.contact)
			$scope.error = 'Invalid Contact';
		else{
			$scope.error = '';
			var c = $scope.contact;
			xservice.save(c);
			$scope.contact = null;
		}
	};	

	$scope.remove = function(id){
		xservice.delete(id);
	};

	$scope.edit = function(id){
		$scope.contact = angular.copy(xservice.get(id));
	};
});