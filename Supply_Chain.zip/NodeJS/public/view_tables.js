var view_tables = angular.module('supplierApp', []);
view_tables.controller('customCtrl', function($scope,$http,$window) 
{
	$http.get("/getuser").then(function (response) 
	{
		if (response.data)
			$scope.user=response.data;
		else
			$window.location.href = "index.html";
	});
	
	$scope.logoff = function()
	{
		$http.get("/logout").then(function (response) {
			if (response.data)
				$window.location.href = "index.html";
		});
	}
  
  $scope.view_supplier=function()
  {
  $http.get("/suppliers").then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=false;
	  $scope.showDelSupplier=false;
	  $scope.supplierData = response.data;
	  $scope.itemData = "";
	  $scope.supplyData = "";
	  $scope.sup_itemData ="";
	  $scope.empty="";
	  //alert(response.data);
	  $scope.col1="Supplier ID";
	  $scope.col2="Name";
	  $scope.col3="Contract Expiry";
  });
  };
  
  $scope.view_item=function()
  {
  $http.get("/items").then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=true;
	  $scope.showDelItem=false;
	  $scope.supplierData = "";
	  $scope.sup_itemData ="";
	  $scope.empty="";
	  
		  $scope.itemData = response.data;
		  $scope.supplyData = "";
		  //alert(response.data);
		  $scope.col1="Item number";
		  $scope.col2="Name";
		  $scope.col3="Supplier ID";
	  
  });
  }
  $scope.supplier_wise=function()
  {
	  $scope.showSupWise=true;
  $http.get("/supplier_wise",{params:{"s_id":$scope.sid}}).then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=true;
	  $scope.showDelItem=false;
	  $scope.supplierData = "";
	  $scope.sup_itemData ="";
	  $scope.empty="";
	  
		  $scope.sup_itemData = response.data;
		  $scope.supplyData = "";
		  $scope.itemData="";
		  //alert(response.data);
		  $scope.col1="Item number";
		  $scope.col2="Name";
		  $scope.col3="";
	  
  });
  }
  
  $scope.view_supply=function()
  {
  $http.get("/supplies").then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=false;
	  $scope.showDelSupply=false;
	  $scope.supplierData = "";
      $scope.itemData = "";
	  $scope.sup_itemData ="";
	  $scope.empty="";
	  
	  if(response.data.length==0)
	  {	
		  $scope.showTable=false;
		  $scope.empty="Database empty!";
	  }
	  else
	  {
		  $scope.supplyData = response.data;
		  //alert(response.data);
		  $scope.col1="Supply ID";
		  $scope.col2="Item Number";
		  $scope.col3="City";
	  
	  }
  });
  }
  
  $scope.update_supplier=function()
  {
  $http.get("/suppliers").then(function (response) {
	  //alert(response.data[0].s_id);
	  $scope.showTable=true;
	  $scope.showAddSupplier=true;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=false;
	  $scope.showDelSupplier=true;
	  $scope.supplierData = response.data;
	  //$scope.supplierData.data[0]+="here";
	  $scope.itemData = "";
	  $scope.supplyData = "";
	  $scope.empty="";
	  //alert(response.data);
	  $scope.col1="Supplier ID";
	  $scope.col2="Name";
	  $scope.col3="Contract Expiry";
  });
  };
  
  $scope.update_item=function()
  {
  $http.get("/items").then(function (response) {
	  //alert(response.data[0].i_id);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=true;
	  $scope.showAddSupply=false;
	  $scope.showSupWise=false;
	  $scope.showDelItem=true;
	  $scope.supplierData = "";
	  $scope.empty="";
      $scope.itemData = response.data;
	  $scope.supplyData = "";
	  //alert(response.data);
	  $scope.col1="Item number";
	  $scope.col2="Name";
	  $scope.col3="Supplier ID";
  });
  }
  
  $scope.update_supply=function()
  {
  $http.get("/supplies").then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.showTable=true;
	  $scope.showAddSupplier=false;
	  $scope.showAddItem=false;
	  $scope.showAddSupply=true;
	  $scope.showSupWise=false;
	  $scope.showDelSupply=true;
	  $scope.supplierData = "";
      $scope.itemData = "";
	  $scope.empty="";
	  if(response.data.length==0)
	  {	
		  $scope.showTable=false;
		  $scope.empty="Database empty!";
	  }
	  else
	  {
		  $scope.supplyData = response.data;
		  //alert(response.data);
		  $scope.col1="Supply ID";
		  $scope.col2="Item Number";
		  $scope.col3="City";
	  
	  }
  });
  }
  
  $scope.delete_supplier=function(index)
  {
	var v;
	  
	if ($window.confirm("Delete "+ (v = $scope.supplierData[index].s_id)+"?")) 
	{  
		$http.get("/del_supplier",{params:{"s_id":v}}).then(function (response) {});
                    $scope.update_supplier();
    } else 
	{
                    alert("Action cancelled.");
    }
  }
  
  $scope.delete_item=function(index)
  {
	var v;
	  
	if ($window.confirm("Delete "+ (v = $scope.itemData[index].i_id)+"?")) 
	{  
		$http.get("/del_item",{params:{"i_id":v}}).then(function (response) {});
                    $scope.update_item();
    } else 
	{
                    alert("Action cancelled.");
    }
  }
  
  $scope.delete_supply=function(index)
  {
	var v;
	  
	if ($window.confirm("Delete "+ (v = $scope.supplyData[index].s_no)+"?")) 
	{  
		$http.get("/del_supply",{params:{"s_no":v}}).then(function (response) {});
                    $scope.update_supply();
    } else 
	{
                    alert("Action cancelled.");
    }
  }
  
  $scope.add_supplier=function(index)
  {
	var v;
	
	$http.get("/supplier_exists",{params:{"s_id":$scope.s_id}})
	.then(function(res)
	{
		if (res.data.length==0)
		{
			if ($window.confirm("Add "+ (v = $scope.s_id)+"?")) 
			{  
				$http.get("/add_supplier",{params:{"s_id":$scope.s_id,"s_name":$scope.s_name,"contract_expiry":$scope.contract_expiry}})
				.then(function (response) {});
							$scope.update_supplier();
			} else 
			{
							alert("Action cancelled.");
			}
		}
		else
			alert("Supplier already exists");
	});
  }
  
  $scope.add_item=function(index)
  {
	var v;
	
	$http.get("/supplier_exists",{params:{"s_id":$scope.supp_id}})
	.then(function(res)
	{
		if (res.data.length>=1)
		{
			$http.get("/item_exists",{params:{"i_id":$scope.i_id}})
			.then(function(r)
			{
				if (r.data.length==0)
				{
					if ($window.confirm("Add "+ (v = $scope.i_id)+"?")) 
					{  
						$http.get("/add_item",{params:{"i_id":$scope.i_id,"i_name":$scope.i_name,"s_id":$scope.supp_id}})
						.then(function (response) {});
									$scope.update_item();
					} else 
					{
									alert("Action cancelled.");
					}
				}
				else
					alert("Item already exists");
			});
		}
		else
			alert("Enter existing supplier");
  });
  }
  
  $scope.add_supply=function(index)
  {
	var v;
	
	$http.get("/item_exists",{params:{"i_id":$scope.it_id}})
	.then(function(res)
	{
		
		if (res.data.length>=1)
		{
			$http.get("/supply_exists",{params:{"s_no":$scope.s_no}})
			.then(function(r)
			{
				if (r.data.length==0)
				{
					var x;
					$http.get("/supplier_count",{params:{"s_no":$scope.s_no,"i_id":$scope.it_id,"city":$scope.city}})
					.then(function (response) 
					{
						alert(response.data[0].s_count);
						if(response.data[0].s_count<10)
						{
							if ($window.confirm("Add "+ (v = $scope.s_no)+"?")) 
							{  
								$http.get("/add_supply",{params:{"s_no":$scope.s_no,"i_id":$scope.it_id,"city":$scope.city}})
								.then(function (response) {});
											$scope.update_supply();
							} else 
							{
											alert("Action cancelled.");
							}
						}
						else
							alert("City has reached supplier limit!");
					});
				}
				else
					alert("Supply already exists");
			});
		}
		else
			alert("Item doesn't exist");
  });
  }
  
});

