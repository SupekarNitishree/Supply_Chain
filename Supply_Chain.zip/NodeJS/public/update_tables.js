var supplier = angular.module('supplierApp', []);
supplier.controller('customCtrl', function($scope, $http) 
{
	var cn="abc";
	var data={"val":cn};
  
  $scope.view_supplier=function()
  {
  $http.get("/suppliers").then(function (response) {
	  //alert(response.data[0].eid);
	  $scope.supplierData = response.data;
	  $scope.itemData = "";
	  $scope.supplyData = "";
	  //alert(response.data);
	  $scope.col1="Supplier ID";
	  $scope.col2="Name";
	  $scope.col3="Contract Expiry";
  });
  };
  
  
});

